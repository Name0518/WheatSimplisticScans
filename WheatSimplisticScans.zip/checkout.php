<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>replit</title>
  <link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
  <div class="homepage">
    <?php include 'menu.php'; ?>
    <?php
    unset($_SESSION['cart']);

?>

<h1>Thank you for shopping</h1>
<p><a href=gallery.php>Continue shopping for more</a></p>

    </div>
      <div>

      </div>
      <script src="script.js"></script>
    </body>

    </html>